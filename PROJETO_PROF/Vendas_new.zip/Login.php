

<!DOCTYPE html>
<?php include "index.php"; ?>
<html>
<head>
<title>Login</title>
</head>
<body>
	<form method="get" action="login_consulta.php">
	<label>Login:</label><input type="text" name="txtlogin" id="login"><br>
	<label>Senha:</label><input type="password" name="pwdsenha" id="senha"><br>
	<input type="submit" value="entrar" id="entrar" name="entrar"><br>
	<!---<a href="cadastrar_usuario.php">Cadastre-se</a>--->
</form>
</body>
</html>