﻿<?php
	include "conexao.php";

	$nome = $_REQUEST['txtnome'];
	$email = $_REQUEST['txtemail'];
	
	
	$insereDados = mysqli_query($conn, "INSERT INTO funcionario (Nome, Email) 
	VALUES ('$nome', '$email')") or die (mysql_error());
	if($insereDados != ""){

		echo 'Cadastrado com sucesso!!!';

	}else{

		echo 'Não cadastrado!!!';
	}
?>